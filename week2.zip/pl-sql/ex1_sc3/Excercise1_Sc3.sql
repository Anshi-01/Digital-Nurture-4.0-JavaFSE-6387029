SET SERVEROUTPUT ON;

DECLARE
  found_flag BOOLEAN := FALSE;
BEGIN
  FOR rec IN (
    SELECT c.name, c.customerID, l.loanID, l.endDate
      FROM loans l
      JOIN customers c ON l.customerID = c.customerID
     WHERE l.endDate BETWEEN SYSDATE AND SYSDATE + 30
  )
  LOOP
    found_flag := TRUE;
    DBMS_OUTPUT.PUT_LINE(
      'Reminder: Customer '||rec.name||
      ' (ID:'||rec.customerID||') – Loan '||rec.loanID||
      ' due on '||TO_CHAR(rec.endDate,'DD-MON-YYYY')
    );
  END LOOP;

  IF NOT found_flag THEN
    DBMS_OUTPUT.PUT_LINE('No loans due in the next 30 days.');
  END IF;
END;
/
