SET SERVEROUTPUT ON;

BEGIN
  FOR res IN (
    SELECT customerID, name, balance
      FROM customers
     WHERE balance > 10000
  )
  LOOP
    UPDATE customers
       SET isvip = 'Y'
     WHERE customerID = res.customerID;

    DBMS_OUTPUT.PUT_LINE(
      'Promoted to VIP: ' || res.name || 
      ' (ID: ' || res.customerID || 
      ', Balance: $' || res.balance || ')'
    );
  END LOOP;
END;
/
