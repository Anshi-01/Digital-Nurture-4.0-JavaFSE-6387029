package in.cognizant.junit;

import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

public class CalculatorLifecycleTest {

    Calculator calc;

    @BeforeEach
    void setUp() {
        System.out.println("Setting up calculator...");
        calc = new Calculator();  // Arrange: This will run before each test
    }

    @AfterEach
    void tearDown() {
        System.out.println("Cleaning up...");
        calc = null;  // Optional cleanup
    }

    @Test
    void testAddition() {
        // Act
        int result = calc.add(2, 3);

        // Assert
        assertEquals(5, result);
    }

    @Test
    void testSubtraction() {
        int result = calc.subtract(10, 4);
        assertEquals(6, result);
    }

    @Test
    void testDivisionByZero() {
        Exception exception = assertThrows(ArithmeticException.class, () -> {
            calc.divide(10, 0);
        });
        assertEquals("Cannot divide by zero", exception.getMessage());
    }
}
