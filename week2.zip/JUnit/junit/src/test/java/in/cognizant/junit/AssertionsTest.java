package in.cognizant.junit;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AssertionsTest {

    @Test
    public void testAssertions() {
        // Assert equals: 2 + 3 should be 5
        assertEquals(5, 2 + 3);

        // Assert true: 5 is greater than 3
        assertTrue(5 > 3);

        // Assert false: 5 is NOT less than 3
        assertFalse(5 < 3);

        // Assert null: This should be null
        assertNull(null);

        // Assert not null: A new object is not null
        assertNotNull(new Object());
    }
}
