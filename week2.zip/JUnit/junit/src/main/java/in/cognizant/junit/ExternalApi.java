package in.cognizant.junit;

public interface ExternalApi {
    String getData();
}
