package com.example.spring1;

public interface Cars {
    String getModels();
}
